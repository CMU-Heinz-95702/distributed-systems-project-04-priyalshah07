// Priyal Shah - priyalsh

package com.example.holidaycalendar;

import com.google.gson.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

@WebServlet("/checkHoliday")
public class HolidayCheckServlet extends HttpServlet {
    private static final String API_KEY = "rLnGct0HFFSrXBpkhTUfbZ9GfZY6YFtM";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String date = request.getParameter("date");
        String country = request.getParameter("country");

        if (date == null || country == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing date or country.");
            return;
        }

        String year = date.substring(0, 4);

        String urlStr = String.format("https://calendarific.com/api/v2/holidays?api_key=%s&country=%s&year=%s",
                API_KEY, URLEncoder.encode(country, StandardCharsets.UTF_8), year);

        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        boolean isHoliday = false;
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
            JsonObject jsonResponse = JsonParser.parseReader(reader).getAsJsonObject();
            JsonArray holidays = jsonResponse
                    .getAsJsonObject("response")
                    .getAsJsonArray("holidays");

            for (JsonElement el : holidays) {
                JsonObject holiday = el.getAsJsonObject();
                String holidayDate = holiday.getAsJsonObject("date").get("iso").getAsString();
                if (holidayDate.equals(date)) {
                    isHoliday = true;
                    break;
                }
            }
        }

        // Log interaction to MongoDB
        String ipAddress = request.getRemoteAddr();
        String deviceInfo = request.getHeader("User-Agent"); // Optional for now
        MongoLogger.logInteraction(country, date, isHoliday ? "Yes" : "No", ipAddress, deviceInfo);


        // Send JSON response
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();
        result.addProperty("date", date);
        result.addProperty("country", country);
        result.addProperty("isHoliday", isHoliday);
        out.println(result.toString());
    }
}
