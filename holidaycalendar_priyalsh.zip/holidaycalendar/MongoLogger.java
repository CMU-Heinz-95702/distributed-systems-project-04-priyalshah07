// Priyal Shah - priyalsh

package com.example.holidaycalendar;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.*;
import org.bson.Document;

import java.time.LocalDateTime;

public class MongoLogger {
    private static final String CONNECTION_STRING =
            "mongodb+srv://Priyal07:Priyal1302@cluster0.jksc2gm.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
    private static final String DB_NAME = "HolidayDB";
    private static final String COLLECTION_NAME = "logs";

    private static final MongoClient mongoClient = MongoClients.create(
            MongoClientSettings.builder()
                    .applyConnectionString(new ConnectionString(CONNECTION_STRING))
                    .build()
    );

    public static void logInteraction(String country, String date, String result) {
        logInteraction(country, date, result, "unknown", "unknown");
    }

    public static void logInteraction(String country, String date, String result, String ip, String deviceInfo) {
        MongoDatabase database = mongoClient.getDatabase(DB_NAME);
        MongoCollection<Document> collection = database.getCollection(COLLECTION_NAME);

        Document doc = new Document("timestamp", LocalDateTime.now().toString())
                .append("country", country)
                .append("date", date)
                .append("isHoliday", result)
                .append("ipAddress", ip)
                .append("deviceInfo", deviceInfo != null ? deviceInfo : "unknown");

        collection.insertOne(doc);
    }

    public static FindIterable<Document> getAllLogs() {
        MongoDatabase database = mongoClient.getDatabase(DB_NAME);
        MongoCollection<Document> collection = database.getCollection(COLLECTION_NAME);
        return collection.find();
    }
}

