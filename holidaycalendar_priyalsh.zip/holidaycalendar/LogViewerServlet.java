
// Priyal Shah - priyalsh

package com.example.holidaycalendar;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import org.bson.Document;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

@WebServlet("/logs")
public class LogViewerServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        Iterable<Document> logs = MongoLogger.getAllLogs();
        List<Document> logList = new ArrayList<>();
        Map<String, Integer> countryCount = new HashMap<>();
        int totalLogs = 0;
        int totalHolidayYes = 0;

        for (Document doc : logs) {
            logList.add(doc);
            totalLogs++;
            String country = doc.getString("country");
            String isHoliday = doc.getString("isHoliday");
            if ("Yes".equalsIgnoreCase(isHoliday)) {
                totalHolidayYes++;
            }
            countryCount.put(country, countryCount.getOrDefault(country, 0) + 1);
        }

        List<Map.Entry<String, Integer>> topCountries = new ArrayList<>(countryCount.entrySet());
        topCountries.sort((a, b) -> b.getValue() - a.getValue());

        out.println("<html><head><title>Holiday Logs</title></head><body>");
        out.println("<h2>Holiday Check Log Dashboard</h2>");

        // Analytics Section
        out.println("<h3>Analytics</h3><ul>");
        out.println("<li>Total Checks: " + totalLogs + "</li>");
        out.println("<li>Total Holidays Found: " + totalHolidayYes + "</li>");
        out.println("<li>Top 3 Countries Searched:</li><ul>");
        for (int i = 0; i < Math.min(3, topCountries.size()); i++) {
            Map.Entry<String, Integer> entry = topCountries.get(i);
            out.printf("<li>%s: %d searches</li>", entry.getKey(), entry.getValue());
        }
        out.println("</ul></ul>");

        // Log Table
        out.println("<h3>All Logs</h3>");
        out.println("<table border='1'><tr>");
        out.println("<th>Timestamp</th><th>Country</th><th>Date</th><th>Is Holiday</th><th>IP</th><th>Device Info</th></tr>");

        for (Document doc : logList) {
            out.println("<tr>");
            out.printf("<td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td>",
                    doc.getString("timestamp"),
                    doc.getString("country"),
                    doc.getString("date"),
                    doc.getString("isHoliday"),
                    doc.getString("ipAddress"),
                    doc.getString("deviceInfo"));
            out.println("</tr>");
        }

        out.println("</table></body></html>");
    }
}
